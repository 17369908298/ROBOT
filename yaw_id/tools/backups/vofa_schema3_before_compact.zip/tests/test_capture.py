import csv
import importlib.util
from pathlib import Path
import random
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('capture',ROOT/'tools/capture_yaw.py')
capture=importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)


def packet(seq=1, schema=3):
    v=[0.0]*23
    v[0]=seq*.005;v[6]=4;v[10]=seq;v[22]=schema
    payload=struct.pack('<23f',*v)
    return payload+struct.pack('<f',zlib.crc32(payload)&0xffffff)+capture.TAIL


class CaptureTests(unittest.TestCase):
    def test_split_noise_corruption_resynchronization(self):
        bad=bytearray(packet(4));bad[12]^=1
        stream=b'noise'+packet(1)+packet(2)+bad+packet(3,2)+packet(5)+packet(6)[:53]
        decoder=capture.Decoder();rows=[];rng=random.Random(100)
        while stream:
            n=rng.randrange(1,94);rows+=decoder.feed(stream[:n]);stream=stream[n:]
        self.assertEqual([int(r[10]) for r in rows],[1,2,5])
        self.assertGreaterEqual(decoder.rejected_candidates,2)

    def test_trailing_payload_tail(self):
        # An infinity elsewhere in a candidate is rejected even with a valid CRC.
        v=[0.0]*23;v[3]=float('inf');v[22]=3
        body=struct.pack('<23f',*v)
        stream=body+struct.pack('<f',zlib.crc32(body)&0xffffff)+capture.TAIL+packet(1)
        self.assertEqual(len(capture.Decoder().feed(stream)),1)

    def test_replay_cli(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw=Path(tmp)/'source.bin';raw.write_bytes(packet(1)+packet(2)+packet(4))
            out=Path(tmp)/'test.csv'
            run=subprocess.run([sys.executable,str(ROOT/'tools/capture_yaw.py'),'--decode',str(raw),
                                '--out',str(out)],capture_output=True,text=True)
            self.assertEqual(run.returncode,0,run.stderr)
            with out.open(newline='') as file:rows=list(csv.DictReader(file))
            self.assertEqual(len(rows),3)
            self.assertEqual(len(rows[0]),24)
            self.assertEqual(float(rows[2]['frame_sequence']),4)
            repeated=subprocess.run([sys.executable,str(ROOT/'tools/capture_yaw.py'),'--decode',str(raw),
                                     '--out',str(out)],capture_output=True)
            self.assertNotEqual(repeated.returncode,0)
            self.assertEqual(raw.read_bytes(),packet(1)+packet(2)+packet(4))

    def test_statistics_wrap(self):
        stats=capture.Statistics()
        for seq in [0xfffffe,0xffffff,0,2]:
            row=list(struct.unpack('<24f',packet(seq)[:96]));stats.add(row)
        self.assertEqual(stats.missing_sequence_frames,1)


if __name__=='__main__':
    unittest.main()
