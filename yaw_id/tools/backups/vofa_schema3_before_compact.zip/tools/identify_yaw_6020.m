function result = identify_yaw_6020(csv_files, options)
% Fit the canonical schema-3 CSV produced by capture_yaw.py.
% No phase shift, age-based alignment, or automatic sign reversal is applied.
% Example: r = identify_yaw_6020("../data/run.csv");
arguments
    csv_files string
    options.TrimSeconds (1,1) double {mustBeNonnegative} = 3
    options.SmoothSamples (1,1) double {mustBeInteger,mustBePositive} = 5
    options.Plot (1,1) logical = true
end
names = split("time_s tau_cmd_nm theta_rad omega_rad_s tau_base_nm tau_id_nm mode flags " + ...
    "motor_feedback_age_ms imu_age_ms frame_sequence motor_sequence imu_sequence tx_drops " + ...
    "can_submit_age_ms tau_meas_nm can_submit_torque_nm excitation_frequency_hz " + ...
    "excitation_amplitude_nm excitation_stage motor_temperature_c pitch_rad schema_version frame_crc24");
samples = []; raw_torque = []; source_file = []; rejected = 0; blocks = 0;
for file_index = 1:numel(csv_files)
    T = readtable(csv_files(file_index), VariableNamingRule="preserve");
    assert(all(ismember(names,T.Properties.VariableNames)), ...
        'Expected canonical schema-3 columns; use tools/capture_yaw.py to decode the binary stream.');
    d = double(T{:,cellstr(names)});
    assert(size(d,1)>20,'Too few frames');
    crc_ok = frame_crc_ok(d);
    % Stop/invalid/stale/timing/CAN-submit failure. Keep slew/clamp/governor frames:
    % I1 already includes those changes, so their torque must not be subtracted.
    invalid_mask = uint32(1+4+8+16+512+1024+8192+16384);
    good = crc_ok & all(isfinite(d),2) & d(:,23)==3 & d(:,7)>0 & ...
        bitand(uint32(d(:,8)),invalid_mask)==0 & d(:,9)<50 & d(:,10)<50;
    active = d(:,7)>0 & isfinite(d(:,1));
    begins = find(active & [true;~active(1:end-1) | diff(d(:,1))<=0]);
    for first = begins'
        last = first;
        while last<size(d,1) && active(last+1) && d(last+1,1)>d(last,1)
            last = last+1;
        end
        trim = d(:,1)>=d(first,1)+options.TrimSeconds & ...
               d(:,1)<=d(last,1)-options.TrimSeconds;
        window = (first:last)';
        selected = good(window) & trim(window);
        dt = diff(d(window,1)); dt = dt(isfinite(dt) & dt>0);
        if isempty(dt), continue; end
        max_gap = 2.5*median(dt);
        % Split at a missing/corrupt frame or a device-time gap, BEFORE filtering/differentiation.
        starts = find(selected & [true;~selected(1:end-1) | diff(d(window,1))>max_gap]);
        for head = starts'
            tail=head;
            while tail<numel(window) && selected(tail+1) && d(window(tail+1),1)-d(window(tail),1)<=max_gap
                tail=tail+1;
            end
            idx=window(head:tail); edge=max(3,options.SmoothSamples);
            if numel(idx)<2*edge+20, continue; end
            time=d(idx,1);
            % Identical centered filtering on both sides of the model; raw CSV remains untouched.
            omega=movmean(d(idx,4),options.SmoothSamples);
            torque=movmean(d(idx,2),options.SmoothSamples);
            accel=gradient(omega,time);
            use=(edge+1):(numel(idx)-edge);
            samples=[samples;accel(use),omega(use),torque(use)]; %#ok<AGROW>
            raw_torque=[raw_torque;d(idx(use),2)]; %#ok<AGROW>
            source_file=[source_file;repmat(file_index,numel(use),1)]; %#ok<AGROW>
            blocks=blocks+1;
        end
    end
    rejected=rejected+sum(~crc_ok);
end
assert(size(samples,1)>100,'Insufficient usable data after CRC, state, crop, and continuity checks.');
alpha=samples(:,1); omega=samples(:,2); torque=samples(:,3);
best=Inf;
for smooth_speed=logspace(log10(.02),log10(2),80)
    phi=[alpha,omega,tanh(omega/smooth_speed)];
    coeff=phi\torque;
    prediction=phi*coeff;
    mse=mean((prediction-torque).^2);
    if mse<best
        best=mse; result=struct('J',coeff(1),'B',coeff(2),'Fc',coeff(3), ...
            'omega_s',smooth_speed,'prediction',prediction,'phi',phi);
    end
end
result.RMSE=sqrt(best); result.MAE=mean(abs(result.prediction-torque));
result.R2=1-sum((result.prediction-torque).^2)/sum((torque-mean(torque)).^2);
result.cond=cond(result.phi); result.samples=size(samples,1); result.crc_rejected=rejected;
result.blocks=blocks; result.phase_shift_s=0;
result.physical=result.J>0 && result.B>=0 && result.Fc>=0;
result.raw_torque=raw_torque; result.source_file=source_file;
fprintf('6020 identification: %d samples / %d blocks; CRC rejected %d\n',result.samples,blocks,rejected);
fprintf('Phase shift = 0 s; I8/I9 are receive ages, not a command-response delay.\n');
fprintf('J = %.9g kg*m^2, B = %.9g N*m*s/rad, Fc = %.9g N*m, omega_s = %.9g rad/s\n', ...
    result.J,result.B,result.Fc,result.omega_s);
fprintf('RMSE = %.9g N*m, MAE = %.9g N*m, R2 = %.6f, cond(Phi) = %.6g\n', ...
    result.RMSE,result.MAE,result.R2,result.cond);
if ~result.physical
    warning('Nonphysical coefficients: do not copy this result into feedforward. Inspect signs, actual-current tracking, synchronization, speed coverage and residuals.');
end
if result.omega_s<=.020001 || result.omega_s>=1.99999
    warning('omega_s reached a search boundary; B and Fc may not be independently identifiable.');
end
if options.Plot
    figure('Name','6020 identification');
    tiledlayout(2,1);
    nexttile;plot(torque,result.prediction,'.');hold on;plot(xlim,xlim,'k--');
    xlabel('recorded total torque (N*m)');ylabel('predicted torque (N*m)');grid on;
    nexttile;plot(result.prediction-torque);xlabel('usable sample');ylabel('residual (N*m)');grid on;
end
end

function valid=frame_crc_ok(d)
% Vectorized CRC32/ISO-HDLC over the original first 23 little-endian float32 values.
[~,~,endian]=computer;
assert(endian=='L','This decoder expects a little-endian host.');
bytes=reshape(typecast(reshape(single(d(:,1:23))',[],1),'uint8'),92,[]);
crc=repmat(uint32(hex2dec('FFFFFFFF')),1,size(d,1));
for index=1:92
    crc=bitxor(crc,uint32(bytes(index,:)));
    for bit=1:8
        crc=bitxor(bitshift(crc,-1),uint32(hex2dec('EDB88320')).*bitand(crc,uint32(1)));
    end
end
valid=(double(bitand(bitcmp(crc),uint32(hex2dec('FFFFFF'))))'==d(:,24));
end
