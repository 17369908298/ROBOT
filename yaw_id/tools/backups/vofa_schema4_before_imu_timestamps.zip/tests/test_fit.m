% Run from the project root after: python tests/make_fit_fixture.py
root=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'tools'));
r=identify_yaw_6020(fullfile(root,'build','host_tests','synthetic.csv'),Plot=false);
assert(abs(r.J/.012-1)<.05);
assert(abs(r.B/.02-1)<.15);
assert(abs(r.Fc/.06-1)<.15);
assert(r.R2>.99 && r.crc_rejected==0 && r.phase_shift_s==0);
legacy=identify_yaw_6020(fullfile(root,'build','host_tests','synthetic_schema3.csv'),Plot=false);
assert(abs(legacy.J-r.J)<1e-10 && abs(legacy.B-r.B)<1e-10 && abs(legacy.Fc-r.Fc)<1e-10);
disp('MATLAB SYNTHETIC FIT PASS');
