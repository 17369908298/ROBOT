"""Known synthetic plant for offline MATLAB regression; this is not captured motor data."""
import csv
import importlib.util
import math
from pathlib import Path
import struct
import zlib

root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('capture',root/'tools/capture_yaw.py')
capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
path=root/'build/host_tests/synthetic.csv';path.parent.mkdir(parents=True,exist_ok=True)
legacy_path=path.with_name('synthetic_schema3.csv')
with path.open('w',newline='',encoding='utf-8') as stream, legacy_path.open('w',newline='',encoding='utf-8') as legacy:
    writer=csv.writer(stream);writer.writerow(capture.COLUMNS)
    legacy_writer=csv.writer(legacy);legacy_writer.writerow(capture.COLUMNS_V3)
    for index in range(10000):
        t=index*.005
        speed=math.sin(2*math.pi*.3*t)+.2*math.sin(2*math.pi*2*t)
        accel=2*math.pi*.3*math.cos(2*math.pi*.3*t)+.4*math.pi*2*math.cos(2*math.pi*2*t)
        torque=.012*accel+.02*speed+.06*math.tanh(speed/.1)
        values=[t,torque,0,speed,1,0,index,2,4]
        compact_body=struct.pack('<9f',*values)
        writer.writerow(struct.unpack('<10f',compact_body+struct.pack('<f',zlib.crc32(compact_body)&0xffffff)))
        values=[t,torque,0,speed,0,0,1,0,0,2,index,index,index,0,0,0,0,1,.3,0,25,0,3]
        body=struct.pack('<23f',*values)
        legacy_writer.writerow(struct.unpack('<24f',body+struct.pack('<f',zlib.crc32(body)&0xffffff)))
print(path)
