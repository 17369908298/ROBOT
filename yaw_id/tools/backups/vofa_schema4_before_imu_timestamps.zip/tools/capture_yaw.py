"""Capture compact schema-4 JustFloat frames, retaining the untouched byte stream.

Serial: pip install pyserial; python tools/capture_yaw.py --port COM16 --out data/run.csv
Replay: python tools/capture_yaw.py --decode data/run.raw.bin --out data/replay.csv
Only captures data; never sends motor commands.
"""
import argparse
import csv
import json
import math
from pathlib import Path
import struct
import time
import zlib

COLUMNS_V3 = (
    'time_s tau_cmd_nm theta_rad omega_rad_s tau_base_nm tau_id_nm mode flags '
    'motor_feedback_age_ms imu_age_ms frame_sequence motor_sequence imu_sequence '
    'tx_drops can_submit_age_ms tau_meas_nm can_submit_torque_nm '
    'excitation_frequency_hz excitation_amplitude_nm excitation_stage '
    'motor_temperature_c pitch_rad schema_version frame_crc24'
).split()
COLUMNS = (
    'time_s tau_cmd_nm theta_rad omega_rad_s mode flags frame_sequence '
    'feedback_age_ms schema_version frame_crc24'
).split()
SCHEMAS = {3: COLUMNS_V3, 4: COLUMNS}
TAIL = b'\x00\x00\x80\x7f'
FRAME_BYTES = len(COLUMNS)*4+4


class Decoder:
    def __init__(self, schema=4):
        self.schema = schema
        self.columns = SCHEMAS[schema]
        self.payload_bytes = len(self.columns)*4
        self.frame_bytes = self.payload_bytes+len(TAIL)
        self.unpack_format = '<'+str(len(self.columns))+'f'
        self.buffer = bytearray()
        self.valid_frames = self.rejected_candidates = self.discarded_bytes = 0

    def feed(self, chunk):
        self.buffer.extend(chunk)
        frames = []
        while len(self.buffer) >= self.frame_bytes:
            end = self.buffer.find(TAIL, self.payload_bytes)
            if end < 0:
                count = len(self.buffer) - (self.frame_bytes-1)
                del self.buffer[:count]
                self.discarded_bytes += count
                break
            start = end - self.payload_bytes
            payload = bytes(self.buffer[start:end])
            values = struct.unpack(self.unpack_format, payload)
            valid = (all(map(math.isfinite, values)) and values[-2] == float(self.schema) and
                     values[-1] == float(zlib.crc32(payload[:-4]) & 0xffffff))
            if valid:
                frames.append(values)
                self.valid_frames += 1
                self.discarded_bytes += start
                del self.buffer[:end+4]
            else:
                self.rejected_candidates += 1
                # Scan every possible tail alignment; a payload can contain the tail bytes.
                count = start + 1
                del self.buffer[:count]
                self.discarded_bytes += count
        return frames


class Statistics:
    def __init__(self, columns=COLUMNS):
        self.index = {name: index for index, name in enumerate(columns)}
        self.last_sequence = self.last_time = None
        self.missing_sequence_frames = self.duplicates = self.rounds = 0
        self.active_frames = 0
        self.dt_min = self.dt_max = None
        self.dt_sum = self.dt_count = 0
        self.max_feedback_age_ms = 0
        self.max_tx_drops = 0 if 'tx_drops' in self.index else None
        self.flag_or = 0

    def add(self, row):
        seq = int(row[self.index['frame_sequence']])
        if self.last_sequence is not None:
            delta = (seq-self.last_sequence) & 0xffffff
            if delta == 0:
                self.duplicates += 1
            elif delta < 0x800000:
                self.missing_sequence_frames += delta-1
            else:
                self.last_time = None  # reset/reboot, not millions of missing packets
        self.last_sequence = seq
        if row[self.index['mode']] > 0:
            self.active_frames += 1
            if 'feedback_age_ms' in self.index:
                age = row[self.index['feedback_age_ms']]
            else:
                age = max(row[self.index['motor_feedback_age_ms']], row[self.index['imu_age_ms']])
            self.max_feedback_age_ms = max(self.max_feedback_age_ms, age)
            if self.last_time is None or row[0] < self.last_time:
                self.rounds += 1
            elif row[0] > self.last_time:
                dt = row[0]-self.last_time
                self.dt_min = dt if self.dt_min is None else min(self.dt_min, dt)
                self.dt_max = dt if self.dt_max is None else max(self.dt_max, dt)
                self.dt_sum += dt
                self.dt_count += 1
            self.last_time = row[0]
        else:
            self.last_time = None
        if self.max_tx_drops is not None:
            self.max_tx_drops = max(self.max_tx_drops, int(row[self.index['tx_drops']]))
        self.flag_or |= int(row[self.index['flags']])

    def report(self):
        result = vars(self).copy()
        result.pop('index')
        result['mean_active_interval_ms'] = 1000*self.dt_sum/self.dt_count if self.dt_count else None
        result['min_active_interval_ms'] = 1000*self.dt_min if self.dt_min is not None else None
        result['max_active_interval_ms'] = 1000*self.dt_max if self.dt_max is not None else None
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--port')
    source.add_argument('--decode', type=Path)
    parser.add_argument('--baud', type=int, default=115200)
    parser.add_argument('--schema', type=int, choices=SCHEMAS, default=4,
                        help='4: compact 10-channel firmware; 3: old 24-channel capture')
    parser.add_argument('--seconds', type=float, default=260)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--notes', default='')
    args = parser.parse_args()
    if args.seconds <= 0 or args.baud <= 0:
        parser.error('seconds and baud must be positive')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    raw_path = args.out.with_suffix('.raw.bin')
    meta_path = args.out.with_suffix('.meta.json')
    if args.decode and args.decode.resolve() == args.out.resolve():
        parser.error('input and output must differ')
    # Refuse accidental overwrites of previous experiments.
    for path in ([args.out, meta_path] if args.decode else [args.out, raw_path, meta_path]):
        if path.exists():
            parser.error('Output already exists: '+str(path))
    decoder = Decoder(args.schema)
    stats = Statistics(decoder.columns)
    start = time.monotonic()
    source_stream = raw_stream = None
    byte_count = 0
    error = None
    try:
        if args.decode:
            source_stream = args.decode.open('rb')
        else:
            try:
                import serial
            except ImportError:
                parser.error('Install pyserial: python -m pip install pyserial')
            source_stream = serial.Serial(args.port, args.baud, timeout=.1)
            raw_stream = raw_path.open('xb')
        with args.out.open('x', newline='', encoding='utf-8') as output:
            writer = csv.writer(output)
            writer.writerow(decoder.columns)
            while args.decode or time.monotonic()-start < args.seconds:
                chunk = source_stream.read(4096 if args.decode else max(1, min(4096, source_stream.in_waiting)))
                if args.decode and not chunk:
                    break
                byte_count += len(chunk)
                if raw_stream:
                    raw_stream.write(chunk)
                for row in decoder.feed(chunk):
                    writer.writerow(row)
                    stats.add(row)
    except KeyboardInterrupt:
        error = 'Interrupted; partial capture retained'
    except Exception as exc:
        error = str(exc)
        raise
    finally:
        for stream in [source_stream, raw_stream]:
            if stream:
                stream.close()
        report = dict(schema_version=args.schema, source=str(args.decode or args.port), baud=args.baud,
                      elapsed_host_s=time.monotonic()-start, bytes=byte_count, notes=args.notes,
                      error=error, valid_frames=decoder.valid_frames,
                      rejected_candidates=decoder.rejected_candidates,
                      discarded_bytes=decoder.discarded_bytes, trailing_bytes=len(decoder.buffer),
                      **stats.report())
        meta_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
        print(json.dumps(report, indent=2, ensure_ascii=False))
    if not decoder.valid_frames:
        raise SystemExit(f'No valid schema-{args.schema} frames: check UART/baud/channel version.')


if __name__ == '__main__':
    main()
